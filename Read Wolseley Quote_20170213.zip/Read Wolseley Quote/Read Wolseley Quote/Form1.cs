﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;
using RASW;

namespace Read_Wolseley_Quote
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        AppSettings appSet = new AppSettings(Path.Combine(Directory.GetCurrentDirectory(), "ReadQuotesShowHide.xml"));

        private void Form1_Activated(object sender, EventArgs e)
        {
            ReadExchangeRates();
            //AppSettings appSet = new AppSettings(Path.Combine(Directory.GetCurrentDirectory(), "ReadQuotesShowHide.xml"));
            if(!Convert.ToBoolean(appSet.getValue("Wolseley")))
                Dispose();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //AppSettings appSet = new AppSettings(Path.Combine(Directory.GetCurrentDirectory(), "ReadQuotesShowHide.xml"));
            bool showGUI = false;

            showGUI = Convert.ToBoolean(appSet.getValue("Wolseley"));

            if (!showGUI)
                Opacity = 0;

            chkShowGUI.Checked = Convert.ToBoolean(appSet.getValue("Wolseley"));
        }

        public void ReadExchangeRates()
        {
            string sheetName = "Polarcirkel 500 FR";
            string filename = Path.Combine(Directory.GetCurrentDirectory() + @"\Data", "170131 Wolseley Price Quote template.xlsx");

            DataTable dt = new DataTable();
            using (OleDbConnection conn = new OleDbConnection())
            {
                conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filename + ";" + "Extended Properties='Excel 12.0 Xml;HDR=YES;IMEX=1;MAXSCANROWS=0'";
                using (OleDbCommand comm = new OleDbCommand())
                {
                    comm.CommandText = "Select * from [" + sheetName + "$]";
                    //comm.CommandText = "Select F1, F3, F4 from [" + sheetName + "$]";
                   // comm.CommandText = "Select C1, C2, C3, C4, C5,C6,C7,C8,C9,C10 from [" + sheetName + "$]";
                    comm.Connection = conn;

                    using (OleDbDataAdapter da = new OleDbDataAdapter())
                    {
                        da.SelectCommand = comm;
                        da.Fill(dt);
                    }
                }
            }

            dataGridView1.DataSource = dt.DefaultView;

            List<string> sheetData  = new  List<string>();

            using (StreamWriter errors = new System.IO.StreamWriter(Path.Combine(Directory.GetCurrentDirectory() + @"\Data", "WolseleyErrors.txt"), false))
            {
                try
                {
                    sheetData.Add(dt.Rows[0][1].ToString());    // Title 
                    sheetData.Add(dt.Rows[1][1].ToString() + "|" + dt.Rows[1][2].ToString() + "|" + dt.Rows[1][3].ToString());                                      // Pen Quantity    
                    sheetData.Add(dt.Rows[2][1].ToString() + "|" + dt.Rows[2][2].ToString() + "|" + dt.Rows[2][3].ToString());                                      // Pipe Spec
                    sheetData.Add(dt.Rows[3][1].ToString() + "|" + dt.Rows[3][2].ToString() + "|" + dt.Rows[3][3].ToString() + "|" + dt.Rows[3][4].ToString());     // Circumference
                    sheetData.Add(dt.Rows[4][1].ToString() + "|" + dt.Rows[4][2].ToString() + "|" + dt.Rows[4][3].ToString() + "|" + dt.Rows[4][4].ToString());     // SinkerTube
                }
                catch (Exception ex)
                {
                    errors.WriteLine("Header section error - " + ex.Message);
                }

                try
                {
                    sheetData.Add(dt.Rows[6][0].ToString() + "|" + dt.Rows[6][1].ToString() + "|" + dt.Rows[6][2].ToString() + "|" + dt.Rows[6][3].ToString() + "|" + dt.Rows[6][4].ToString() + "|" + dt.Rows[6][5].ToString() + "|" + dt.Rows[6][6].ToString() + "|" + dt.Rows[6][7].ToString() + "|" + dt.Rows[6][8].ToString() + "|" + dt.Rows[6][9].ToString());   // Column Titles
                }
                catch (Exception ex)
                {
                    errors.WriteLine("Column titles section error - " + ex.Message);
                }

                try
                {
                    sheetData.Add("#" + dt.Rows[8][1].ToString());    // Equipment Title (# = title)

                    sheetData.Add(dt.Rows[9][0].ToString() + "|" + dt.Rows[9][1].ToString() + "|" + dt.Rows[9][2].ToString() + "|" + dt.Rows[9][3].ToString() + "|" + dt.Rows[9][4].ToString() + "|" + dt.Rows[9][5].ToString() + "|" + dt.Rows[9][6].ToString() + "|" + dt.Rows[9][7].ToString() + "|" + dt.Rows[9][8].ToString() + "|" + dt.Rows[9][9].ToString());   // Floating Structures 1

                    sheetData.Add(dt.Rows[10][0].ToString() + "|" + dt.Rows[10][1].ToString() + "|" + dt.Rows[10][2].ToString() + "|" + dt.Rows[10][3].ToString() + "|" + dt.Rows[10][4].ToString() + "|" + dt.Rows[10][5].ToString() + "|" + dt.Rows[10][6].ToString() + "|" + dt.Rows[10][7].ToString() + "|" + dt.Rows[10][8].ToString() + "|" + dt.Rows[10][9].ToString());   // Floating Structures 2
                }
                catch (Exception ex)
                {
                    errors.WriteLine("Floating Structures section error - " + ex.Message);
                }

                try
                {
                    sheetData.Add("#" + dt.Rows[11][1].ToString());    // Equipment Title  (# = title)

                    sheetData.Add(dt.Rows[12][0].ToString() + "|" + dt.Rows[12][1].ToString() + "|" + dt.Rows[12][2].ToString() + "|" + dt.Rows[12][3].ToString() + "|" + dt.Rows[12][4].ToString() + "|" + dt.Rows[12][5].ToString() + "|" + dt.Rows[12][6].ToString() + "|" + dt.Rows[12][7].ToString() + "|" + dt.Rows[12][8].ToString() + "|" + dt.Rows[12][9].ToString());   // Sinkertube

                }
                catch (Exception ex)
                {
                    errors.WriteLine("Sinkertube section error - " + ex.Message);
                }

                try
                {
                    sheetData.Add("#" + dt.Rows[13][1].ToString());    // Equipment Title  (# = title) 

                    sheetData.Add(dt.Rows[14][0].ToString() + "|" + dt.Rows[14][1].ToString() + "|" + dt.Rows[14][2].ToString() + "|" + dt.Rows[14][3].ToString() + "|" + dt.Rows[14][4].ToString() + "|" + dt.Rows[14][5].ToString() + "|" + dt.Rows[14][6].ToString() + "|" + dt.Rows[14][7].ToString() + "|" + dt.Rows[14][8].ToString() + "|" + dt.Rows[14][9].ToString());   // Walkways

                }
                catch (Exception ex)
                {
                    errors.WriteLine("Walkways section error - " + ex.Message);
                }

                StreamWriter file = new System.IO.StreamWriter(Path.Combine(Directory.GetCurrentDirectory() + @"\Data", "Wolseley.txt"), false);   // overwrite file each time
                foreach (var line in sheetData)
                {
                    file.WriteLine(line);
                }

                file.Close();
            }

            try
            {
                string path = Path.Combine(Directory.GetCurrentDirectory() + @"\Data", "WolseleyErrors.txt");
          
               if (new FileInfo(path).Length == 0) File.Delete(path);   // if file size is equal to zero then no errors have been reported so delete the file
            }
            catch { }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void chkShowGUI_CheckedChanged(object sender, EventArgs e)
        {
            //AppSettings appSet = new AppSettings(Path.Combine(Directory.GetCurrentDirectory(), "ReadQuotesShowHide.xml"));
            if(chkShowGUI.Checked)
                appSet.setValue("Wolseley", true.ToString());
            else
                appSet.setValue("Wolseley", false.ToString());
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
          
        }
    }
}
